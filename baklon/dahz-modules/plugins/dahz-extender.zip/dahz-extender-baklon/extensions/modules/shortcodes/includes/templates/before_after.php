<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
[0] => image_before
[1] => image_after
[2] => marker_color
[3] => active_marker_color
[4] => icon_color
[5] => active_icon_color
[6] => css_animation
[7] => animation_parallax
[8] => delay_animation
[9] => repeat_animation
[10] => el_class
[11] => margin
[12] => remove_top_margin
[13] => remove_bottom_margin
[14] => visibility
[15] => enable_dahz_lazy_shortcode
[16] => dahz_id
*/

wp_enqueue_style( "beer-slider" );

# setup container attribute
$container_attributes = array( 'class'	=> array( 'de-before-after uk-inline' ) );

$_image_before = wp_get_attachment_image( $image_before, 'full' );

$_image_after =  wp_get_attachment_image( $image_after, 'full' );

?>
<div <?php
	dahz_shortcode_set_attributes(
		$container_attributes,
		'before_after_container',
		$atts
	); ?>>
	<figure class="cd-image-container beer-slider" data-uk-before_after data-beer-label="<?php echo esc_attr( $original_text )?>">
		<?php echo $_image_before;?>
		<div class="cd-resize-img beer-reveal" style="border-right:<?php echo $divider_width;?>px solid <?php echo $divider_color;?>;" data-beer-label="<?php echo esc_attr( $modified_text )?>"> <!-- the resizable image on top -->
			<?php echo $_image_after;?>
		</div>
	</figure>
</div>
