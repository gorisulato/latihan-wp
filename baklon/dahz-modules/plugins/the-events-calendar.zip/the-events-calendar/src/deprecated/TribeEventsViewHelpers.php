<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__View_Helpers' );


	class TribeEventsViewHelpers extends Tribe__View_Helpers {

	}
