<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Cache' );


	class TribeEventsCache extends Tribe__Events__Cache {

	}