<?php
// Reports widget markup
// #reports-app is replaced by React app
?>
<div id="givewp-reports-widget">
	<div class="givewp-loading-notice">
		<div class="givewp-loading-notice__card">
			<div class="givewp-spinner"></div>
			<h2>
				<?php echo __( 'Loading your latest', 'give' ) . '<br>' . __( 'donation activity', 'give' ); ?>
			</h2>
		</div>
	</div>
</div>
