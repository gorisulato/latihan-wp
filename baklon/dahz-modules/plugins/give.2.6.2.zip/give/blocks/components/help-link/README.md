GiveHelpLink
=======

GiveHelpLink is used to generate a text & help link to a page on the website.

![givehelplink](https://user-images.githubusercontent.com/1039236/36345763-16f8d94e-1457-11e8-9b2b-19a336591a86.png)

## Usage

Render a text & link to help.
```jsx
<GiveHelpLink />
```

## Props

No props.